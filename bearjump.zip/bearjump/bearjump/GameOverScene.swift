//
//  GameOverScene.swift
//  bearjump
//
//  Created by Priya Agarwal on 12/5/16.
//  Copyright © 2016 Priya Agarwal. All rights reserved.
//

import Foundation
import SpriteKit

class GameOverScene: SKScene {
    
    init(size: CGSize, won:Bool) {
        super.init(size: size)
        let message = won ? "You Won!" : "You Lose"
        
        let label = SKLabelNode(fontNamed: "Helvetica Neue Ultra Light")
        label.text = message
        label.fontSize = 40
        label.fontColor = SKColor.white
        label.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(label)
        
        let score = SKLabelNode(fontNamed: "Helvetica Neue Ultra Light")
        score.text = String(GameScene.score)
        score.fontSize = 40
        score.fontColor = SKColor.white
        score.position = CGPoint(x: size.width/2, y: size.height/2 - 200)
        addChild(score)
        
        run(SKAction.sequence([
            SKAction.wait(forDuration: 3.0),
            SKAction.run() {
                // 5
                let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
                let scene = MainMenuScene(fileNamed: "MainMenuScene")
                self.view?.presentScene(scene!, transition:reveal)
            }
        ]))
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
