//
//  MainMenuScene.swift
//  BearJump
//
//  Created by Neil Ambar Gupta on 12/4/16.
//  Copyright © 2016 BearJump. All rights reserved.
//

import SpriteKit
import GameplayKit

class MainMenuScene: SKScene {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        for touch in touches {
            let location = touch.location(in: self)
            
            if (atPoint(location).name == "Start") {
                if let scene = GameScene(fileNamed: "GameScene") {
                    // Set the scale mode to scale to fit the window
                    scene.scaleMode = .aspectFill
                    
                    // Present the scene
                    view!.presentScene(scene, transition: SKTransition.crossFade(withDuration: TimeInterval(2)))
                }
            } else if (atPoint(location).name == "High Score") {
                if let scene = HighScoreScene(fileNamed: "HighScoreScene") {
                    // Set the scale mode to scale to fit the window
                    scene.scaleMode = .aspectFill
                    
                    // Present the scene
                    view!.presentScene(scene, transition: SKTransition.doorsOpenVertical(withDuration: TimeInterval(2)))
                }
            }
        }
    }
}
