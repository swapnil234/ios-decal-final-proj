//
//  GameScene.swift
//  bearjump
//
//  Created by Priya Agarwal on 12/4/16.
//  Copyright © 2016 Priya Agarwal. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {

    var ground = SKSpriteNode()
    var tree = SKSpriteNode()
    var bg = SKSpriteNode()
    var BearImage = SKSpriteNode()
    var TextureAtlas = SKTextureAtlas()
    var TextureArray = [SKTexture]()
    var JumpArray = [SKTexture]()
    var JumpAtlas = SKTextureAtlas()
    
    var viewController : UIViewController!
    static var score = 0
//    var scoreLabel = SKLabelNode()
    
    
    override func didMove(to view: SKView) {
        GameScene.score = 0
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        createGrounds()
        createTrees()
        
        TextureAtlas = SKTextureAtlas(named: "Images")
        
        for i in 1...TextureAtlas.textureNames.count {
            let Name = "bear\(i).png"
            TextureArray.append(SKTexture(imageNamed: Name))
        }
        
        let scoreLabel = self.childNode(withName: "scoreNode") as? SKLabelNode
        scoreLabel?.text = String(GameScene.score)
        
       
//        scoreLabel.position = CGPoint(x: 980, y: 700)
        
        BearImage = SKSpriteNode(imageNamed: TextureAtlas.textureNames[0])
        BearImage.size = CGSize(width: 148.5, height: 105)
        BearImage.position = CGPoint(x: -(self.frame.size.width/2) + 120, y: -(self.frame.size.height/2) + 190)
        self.addChild(BearImage)
        BearImage.zPosition = 3
        BearImage.run(SKAction.repeatForever(SKAction.animate(with: TextureArray, timePerFrame: 0.15)), withKey: "aKey")
    }
    func createGrounds() {
        
        for i in 0...3 {
            let ground = SKSpriteNode(imageNamed: "ground")
            ground.name = "Ground"
            ground.size = CGSize(width: (self.scene?.size.width)!, height: 350)
            ground.anchorPoint = CGPoint(x:0.5, y:0.5)
            ground.position = CGPoint(x: CGFloat(i) * ground.size.width, y: -(self.frame.size.height/2) + 100)
            self.addChild(ground)
            
        }
        
    }
    
    func moveGrounds() {
        self.enumerateChildNodes(withName:"Ground", using: ({(node, error) in
            
            node.position.x -= 8
            
            if node.position.x < -((self.scene?.size.width)!) {
                node.position.x += (self.scene?.size.width)! * 3
            }
            
        }))
    }
    
    func createTrees() {
        
        
        let tree = SKSpriteNode(imageNamed: "tree")
        tree.name = "Tree"
        tree.size = CGSize(width: tree.size.width, height: tree.size.height)
        tree.anchorPoint = CGPoint(x:0.5, y:0.5)
        tree.position = CGPoint(x: tree.size.width + CGFloat(arc4random_uniform(UInt32(self.frame.size.width))),
                                y: -(self.frame.size.height/2) + 220)
        tree.zPosition = 3
        self.addChild(tree)
        
        
        
    }
    
    func moveTrees() {
        self.enumerateChildNodes(withName:"Tree", using: ({(node, error) in
            
            node.position.x -= 8
            self.checkState(position: node.position.x)
            
            if node.position.x < -((self.scene?.size.width)!/2) {
                GameScene.score += 1
                node.position.x += CGFloat(arc4random_uniform(UInt32(self.frame.size.width))) + 2*self.frame.size.width
            }
            
        }))
    }
    
    

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        bearJump()
        BearImage.run(SKAction.repeatForever(SKAction.animate(with: TextureArray, timePerFrame: 0.15)), withKey: "aKey")
    }
    
    func bearJump() {
        if BearImage.position.y <= -(self.frame.size.height/2) + 210 {
            BearImage.removeAction(forKey: "aKey")
            BearImage.texture = TextureArray[0]
            // move up 20
            let jumpUpAction = SKAction.moveBy(x: 30, y:270, duration:0.5)
            // move down 20
            let jumpDownAction = SKAction.moveBy(x: -30, y:-270, duration:0.75)
            // sequence of move yup then down
            let jumpSequence = SKAction.sequence([jumpUpAction, jumpDownAction])
            
            // make player run sequence
            BearImage.run(jumpSequence)
        }
        
    }
    
    func checkState(position: CGFloat) {
//        print(position)
        if (((position > (BearImage.position.x) - 3) && (position < (BearImage.position.x) + 3)) && (BearImage.position.y < -(self.frame.size.height/2) + 400)) {
            if HighScoreScene.highScore < (GameScene.score) {
                HighScoreScene.highScore = GameScene.score
            }
            let reveal = SKTransition.crossFade(withDuration: 0.5)
            let gameOverScene = GameOverScene(size: self.size, won: false)
            self.view?.presentScene(gameOverScene, transition: reveal)
        }
    }

    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        moveGrounds()
        moveTrees()
        let scoreLabel = self.childNode(withName: "scoreNode") as? SKLabelNode
        scoreLabel?.text = String(GameScene.score)
    }
}
